# Proyecto_Platzi_1
Proyectos realizados en los cursos de Platzi (programacion-basica).
